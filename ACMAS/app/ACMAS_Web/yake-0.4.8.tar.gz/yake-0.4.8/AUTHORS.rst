=======
Credits
=======

Development
----------------

* Ricardo Campos <arrp@inesctec.pt>
* Vitor Mangaravite <arrp@inesctec.pt>
* Arian Pasquali <arrp@inesctec.pt>
* Alípio Jorge <arrp@inesctec.pt>

Contributors
------------

None yet. Why not be the first?


DevOps - Docker
----------------
* João Rocha da Silva <joaorosilva@gmail.com>
